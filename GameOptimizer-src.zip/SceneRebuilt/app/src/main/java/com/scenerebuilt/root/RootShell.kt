package com.scenerebuilt.root

import com.topjohnwu.superuser.Shell
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object RootShell {
    
    suspend fun isRoot(): Boolean = withContext(Dispatchers.IO) {
        try { Shell.getShell().isRoot } catch (e: Exception) { false }
    }
    
    suspend fun exec(cmd: String): String = withContext(Dispatchers.IO) {
        try { Shell.cmd(cmd).exec().out.joinToString("\n") } catch (e: Exception) { "" }
    }
    
    suspend fun execOk(cmd: String): Boolean = withContext(Dispatchers.IO) {
        try { Shell.cmd(cmd).exec().isSuccess } catch (e: Exception) { false }
    }
    
    suspend fun readFile(path: String): String = withContext(Dispatchers.IO) {
        try { Shell.cmd("cat $path 2>/dev/null").exec().out.firstOrNull()?.trim() ?: "" }
        catch (e: Exception) { "" }
    }
}
